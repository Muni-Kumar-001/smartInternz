//Quiz.js
import mongoose from "mongoose";

const QuestionSchema = new mongoose.Schema(
    {
        question: { type: String, required: [true, "Question is required"] },
        options: {
            type: [String],
            required: [true, "Options are required"],
            validate: [(arr) => arr.length >= 4, "At least four options are required"]
        },
        correctAnswer: {
            type: String,
            required: [true, "Correct answer is required"],
            validate: {
                validator: function (value) {
                    return this.options.includes(value);
                },
                message: "Correct answer must be one of the provided options"
            }
        }
    },
    { timestamps: true }
);

const QuizSchema = new mongoose.Schema(
    {
        course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
        questions: {
            type: [QuestionSchema],
            required: true,
            validate: [(arr) => arr.length >= 1, "Quiz must have at least one question"]
        }
    },
    { timestamps: true }
);

export default mongoose.model("Quiz", QuizSchema);